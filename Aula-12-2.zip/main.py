#==========================================#
print('----Calculadora de dias de carro alugado----')

d = int(input('Quantos dias o carro ficou alugado: '))
k = float(input('Quantos km foram rodados: ').replace(',','.'))

paga=(d*60)+(k*0.15)

print('O valor a ser pago é R${:.2f} devido a {:.0f} dias de aluguel e {:.0f} Km rodados'.format(paga,d,k))
