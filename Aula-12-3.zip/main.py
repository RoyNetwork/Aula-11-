


#==========================================#
qtde = int(input('Informe quantos cigarros você fuma: '))
anos = int(input('Informe por quantos anos você fuma: '))
soma = qtde*(anos*365)
minutos = soma*10

subtrai = (minutos/60)/24

print('Você tem %.2f dias a menos de vida' %subtrai)