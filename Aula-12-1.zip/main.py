__Author__ = 'Alan (Roy)'
print('----Conversor temperatura Celsius para Fahrenheit----')

c = float(input('Insira a temperatura em Celsius: ').replace(',','.'))
f = (9*(c/5)+32)
print('Fahrenheit : {:.2f}'.format(f))




print('\n\n----Conversor temperatura Fahrenheit para Celsius----')

f = float(input('Insira a temperatura em Fahrenheit: ').replace(',','.'))
c = ((f-32)/1.8)
print('Celsius : {:.2f}'format(c))